import { prisma } from '@/config/prisma'
import { createServerSupabaseClient } from '@/config/supabase/server'
import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'
import { buscarPerfilUsuario, ehAdminOuCoAdmin } from '../../_lib/auth'
import { tratarErroPrisma } from '../../_lib/prisma-errors'

// GET /api/matches/:id — retorna detalhes completos de uma partida
export async function GET(
    _request: NextRequest,
    { params }: { params: Promise<{ id: string }> }
) {
    try {
        const supabase = await createServerSupabaseClient()
        const { data: { user } } = await supabase.auth.getUser()

        if (!user) {
            return NextResponse.json({ error: 'Não autorizado' }, { status: 401 })
        }

        const { id } = await params

        const partida = await prisma.matches.findUnique({
            where: { id },
            include: {
                users: { select: { id: true, name: true } },
                match_teams: { orderBy: { team_index: 'asc' } },
                match_players: {
                    include: {
                        users: { select: { id: true, name: true, nickname: true, photo_url: true, position: true, is_goalkeeper: true } },
                        guest_players: { select: { id: true, name: true } },
                    },
                },
                match_rounds: { orderBy: { round_number: 'asc' } },
                goals: {
                    include: {
                        users: { select: { id: true, name: true, nickname: true } },
                        guest_players: { select: { id: true, name: true } },
                    },
                },
                goals_conceded: {
                    include: {
                        users: { select: { id: true, name: true, nickname: true } },
                        guest_players: { select: { id: true, name: true } },
                    },
                },
                mvp_voting_sessions: true,
            },
        })

        if (!partida) {
            return NextResponse.json({ error: 'Partida não encontrada' }, { status: 404 })
        }

        return NextResponse.json(partida)
    } catch (error) {
        console.error('[GET /api/matches/:id]', error)
        return NextResponse.json({ error: 'Erro interno do servidor' }, { status: 500 })
    }
}

// PATCH /api/matches/:id — atualiza status ou dados de uma partida
export async function PATCH(
    request: NextRequest,
    { params }: { params: Promise<{ id: string }> }
) {
    try {
        const supabase = await createServerSupabaseClient()
        const { data: { user } } = await supabase.auth.getUser()

        if (!user) {
            return NextResponse.json({ error: 'Não autorizado' }, { status: 401 })
        }

        const perfilSolicitante = await buscarPerfilUsuario(user.id)
        if (!ehAdminOuCoAdmin(perfilSolicitante?.role)) {
            return NextResponse.json({ error: 'Sem permissão para realizar esta ação' }, { status: 403 })
        }

        const { id } = await params
        const body = await request.json()
        const { status, location, match_date } = body

        const statusValidos = ['scheduled', 'completed', 'cancelled']
        if (status && !statusValidos.includes(status)) {
            return NextResponse.json({ error: `Status inválido. Use: ${statusValidos.join(', ')}` }, { status: 400 })
        }

        const dadosParaAtualizar: Record<string, unknown> = {}
        if (status !== undefined) dadosParaAtualizar.status = status
        if (location !== undefined) dadosParaAtualizar.location = location
        if (match_date !== undefined) dadosParaAtualizar.match_date = new Date(match_date)

        const partidaAtualizada = await prisma.matches.update({
            where: { id },
            data: dadosParaAtualizar,
        })

        return NextResponse.json(partidaAtualizada)
    } catch (error) {
        const respostaPrisma = tratarErroPrisma(error)
        if (respostaPrisma) return respostaPrisma

        console.error('[PATCH /api/matches/:id]', error)
        return NextResponse.json({ error: 'Erro interno do servidor' }, { status: 500 })
    }
}

// DELETE /api/matches/:id — cancela e remove uma partida (cascade no banco)
export async function DELETE(
    _request: NextRequest,
    { params }: { params: Promise<{ id: string }> }
) {
    try {
        const supabase = await createServerSupabaseClient()
        const { data: { user } } = await supabase.auth.getUser()

        if (!user) {
            return NextResponse.json({ error: 'Não autorizado' }, { status: 401 })
        }

        const perfilSolicitante = await buscarPerfilUsuario(user.id)
        if (!ehAdminOuCoAdmin(perfilSolicitante?.role)) {
            return NextResponse.json({ error: 'Sem permissão para realizar esta ação' }, { status: 403 })
        }

        const { id } = await params

        await prisma.matches.delete({ where: { id } })

        return NextResponse.json({ message: 'Partida removida com sucesso' })
    } catch (error) {
        const respostaPrisma = tratarErroPrisma(error)
        if (respostaPrisma) return respostaPrisma

        console.error('[DELETE /api/matches/:id]', error)
        return NextResponse.json({ error: 'Erro interno do servidor' }, { status: 500 })
    }
}
